import { defineConfig } from 'vite';

export default defineConfig({
  base: '/crypto-lab-hybrid-guide/',
});
