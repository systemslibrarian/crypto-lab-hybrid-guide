// ui.ts — hybrid cryptography guide UI.
import {
	freshComponents,
	deriveSessionKey,
	assess,
	bytesToHex,
	type Components,
	type Combiner,
	type BreakState,
} from './engine.ts';
import { DECISION, DEPLOYMENTS, PITFALLS } from './data.ts';

function el<K extends keyof HTMLElementTagNameMap>(
	tag: K,
	className?: string,
	html?: string,
): HTMLElementTagNameMap[K] {
	const node = document.createElement(tag);
	if (className) node.className = className;
	if (html !== undefined) node.innerHTML = html;
	return node;
}

function renderHero(): HTMLElement {
	const hero = el('header', 'hero-panel');
	hero.innerHTML = `
    <button id="theme-toggle" class="theme-toggle" type="button" aria-label="Switch theme">\u{1F319}</button>
    <div class="hero-copy">
      <a class="portfolio-badge" href="https://github.com/systemslibrarian?tab=repositories&q=crypto-lab">crypto-lab \u00b7 portfolio</a>
      <p class="eyebrow">Post-Quantum \u00b7 Migration</p>
      <h1>Hybrid Guide</h1>
      <p class="hero-text">
        During the transition to post-quantum cryptography, the safe move is not to replace
        classical algorithms but to <em>combine</em> them with post-quantum ones. A hybrid KEM
        runs both a classical key exchange (X25519) and a post-quantum one (ML-KEM) and binds the
        results, so the session key stays secret as long as <em>either</em> half holds. This lab
        shows how the combiner works, lets you break each half to see the hedge in action, and
        walks through when and how to deploy hybrids.
      </p>
      <details class="why-details">
        <summary>Why hybrid instead of pure PQC?</summary>
        <p>
          Two risks at once: a quantum computer could break classical X25519, and undiscovered
          cryptanalysis could weaken a young PQC scheme. A hybrid hedges both \u2014 an attacker has
          to break both halves at the same time. It is the recommended interim strategy until
          PQC has years of scrutiny behind it.
        </p>
      </details>
    </div>
    <div class="hero-metric-card">
      <p class="hero-metric-label">The hybrid promise</p>
      <p class="hero-metric-value">secure if<br/>X25519 holds<br/><strong>OR</strong><br/>ML-KEM holds</p>
      <p class="hero-metric-note">Break one, the other still protects you</p>
    </div>
  `;
	return hero;
}

// --- combiner playground ---------------------------------------------------
function renderPlayground(): HTMLElement {
	const section = el('section', 'lab-section');
	section.setAttribute('aria-labelledby', 'playground-heading');
	section.innerHTML = `
    <div class="section-heading-row">
      <div>
        <p class="section-kicker">Live demo</p>
        <h2 id="playground-heading">The Combiner</h2>
        <p class="section-footnote">
          Two component shared secrets feed a combiner that derives one session key (real SHA-256
          via Web Crypto). Break a component to see whether the session key stays unpredictable.
        </p>
      </div>
    </div>

    <div class="combiner-flow">
      <div class="comp-card comp-card--classical" id="card-classical">
        <p class="comp-label">Classical \u00b7 X25519</p>
        <p class="mono-inline comp-secret" id="ss-classical">\u2014</p>
        <label class="break-toggle"><input type="checkbox" id="break-classical" /> Quantum computer breaks this</label>
      </div>
      <div class="comp-card comp-card--pq" id="card-pq">
        <p class="comp-label">Post-Quantum \u00b7 ML-KEM-768</p>
        <p class="mono-inline comp-secret" id="ss-pq">\u2014</p>
        <label class="break-toggle"><input type="checkbox" id="break-pq" /> Cryptanalysis breaks this</label>
      </div>
    </div>

    <div class="combiner-bar">
      <label>Combiner:
        <select id="combiner">
          <option value="xwing" selected>X-Wing-style (bound)</option>
          <option value="naive">Naive concatenation</option>
        </select>
      </label>
      <button id="regen" class="ghost-button" type="button">New session</button>
    </div>

    <div class="session-out panel-card">
      <div class="panel-header">
        <h3>Derived session key</h3>
        <span id="verdict-chip" class="vs-chip">\u2014</span>
      </div>
      <p class="mono-block" id="session-key">\u2014</p>
      <div class="entropy">
        <p class="hero-metric-label">Attacker\u2019s remaining uncertainty</p>
        <div class="entropy-track"><div class="entropy-fill" id="entropy-fill" style="width:0%"></div></div>
        <p class="mono-inline" id="entropy-val">\u2014</p>
      </div>
      <p class="panel-copy" id="verdict-detail"></p>
    </div>
  `;

	const $ = (id: string) => section.querySelector('#' + id) as HTMLElement;
	let comps: Components = freshComponents();

	const breakClassical = $('break-classical') as HTMLInputElement;
	const breakPq = $('break-pq') as HTMLInputElement;
	const combinerSel = $('combiner') as HTMLSelectElement;

	async function refresh(): Promise<void> {
		const combiner = combinerSel.value as Combiner;
		const state: BreakState = {
			classicalBroken: breakClassical.checked,
			pqBroken: breakPq.checked,
		};

		// show secrets (struck through when "broken" / known to attacker)
		$('ss-classical').textContent = bytesToHex(comps.classical).slice(0, 24) + '\u2026';
		$('ss-pq').textContent = bytesToHex(comps.pq).slice(0, 24) + '\u2026';
		$('card-classical').classList.toggle('is-broken', state.classicalBroken);
		$('card-pq').classList.toggle('is-broken', state.pqBroken);

		const key = await deriveSessionKey(comps, combiner);
		$('session-key').textContent = bytesToHex(key);

		const v = assess(state, combiner);
		const pct = (v.remainingBits / 512) * 100;
		const fill = $('entropy-fill');
		fill.style.width = `${pct}%`;
		fill.className = 'entropy-fill ' + (v.secure ? 'entropy-fill--ok' : 'entropy-fill--bad');
		$('entropy-val').textContent = `${v.remainingBits} bits to guess`;

		const chip = $('verdict-chip');
		chip.className = 'vs-chip ' + (v.secure ? 'vs-chip--ok' : 'vs-chip--bad');
		chip.textContent = v.headline;
		$('verdict-detail').innerHTML = v.detail;
	}

	breakClassical.addEventListener('change', refresh);
	breakPq.addEventListener('change', refresh);
	combinerSel.addEventListener('change', refresh);
	$('regen').addEventListener('click', () => {
		comps = freshComponents();
		void refresh();
	});

	void refresh();
	return section;
}

// --- decision guide --------------------------------------------------------
function renderDecision(): HTMLElement {
	const section = el('section', 'lab-section');
	const steps = DECISION.map(
		(d, i) => `
    <div class="decision-step">
      <div class="decision-num">${i + 1}</div>
      <div>
        <h3>${d.question}</h3>
        <p class="panel-copy"><span class="dec-tag dec-tag--yes">Yes</span> ${d.yes}</p>
        <p class="panel-copy"><span class="dec-tag dec-tag--no">No</span> ${d.no}</p>
      </div>
    </div>`,
	).join('');
	section.innerHTML = `
    <div class="section-heading-row">
      <div>
        <p class="section-kicker">Decide</p>
        <h2>Should You Go Hybrid?</h2>
        <p class="section-footnote">Four questions that settle most cases. For long-lived secrets, the answer is almost always yes.</p>
      </div>
    </div>
    <div class="decision-flow">${steps}</div>
  `;
	return section;
}

// --- deployments -----------------------------------------------------------
function renderDeployments(): HTMLElement {
	const section = el('section', 'lab-section');
	const cards = DEPLOYMENTS.map(
		(d) => `
    <div class="panel-card">
      <h3>${d.name}</h3>
      <p class="panel-copy">${d.detail}</p>
    </div>`,
	).join('');
	section.innerHTML = `
    <div class="section-heading-row">
      <div>
        <p class="section-kicker">In the wild</p>
        <h2>Hybrids in Production</h2>
      </div>
    </div>
    <div class="playground-grid">${cards}</div>
  `;
	return section;
}

// --- pitfalls --------------------------------------------------------------
function renderPitfalls(): HTMLElement {
	const section = el('section', 'lab-section');
	const good = PITFALLS.filter((p) => p.good)
		.map((p) => `<li><strong>${p.title}.</strong> ${p.body}</li>`)
		.join('');
	const bad = PITFALLS.filter((p) => !p.good)
		.map((p) => `<li><strong>${p.title}.</strong> ${p.body}</li>`)
		.join('');
	section.innerHTML = `
    <div class="section-heading-row">
      <div>
        <p class="section-kicker">Practice</p>
        <h2>Do and Don\u2019t</h2>
      </div>
    </div>
    <div class="reuse-grid">
      <div class="panel-card">
        <h3>Do</h3>
        <ul class="trait-list trait-list--good">${good}</ul>
      </div>
      <div class="panel-card">
        <h3>Watch out</h3>
        <ul class="trait-list trait-list--bad">${bad}</ul>
      </div>
    </div>
  `;
	return section;
}

function renderFooter(): HTMLElement {
	const footer = el('footer', 'lab-section');
	footer.innerHTML = `
    <p class="section-footnote">
      The combiner uses real SHA-256 over simulated 32-byte component secrets to illustrate the
      construction; production hybrids like X-Wing use ML-KEM-768, X25519, and SHA3-256 with a
      formally analysed combiner. Educational use only \u2014 use a vetted library for deployment.
    </p>
    <p class="scripture">\u201CSo whether you eat or drink or whatever you do, do it all for the glory of God.\u201D \u2014 1 Corinthians 10:31</p>
  `;
	return footer;
}

export function mountApp(root: HTMLDivElement): void {
	const shell = el('div', 'page-shell');
	shell.append(
		renderHero(),
		renderPlayground(),
		renderDecision(),
		renderDeployments(),
		renderPitfalls(),
		renderFooter(),
	);
	root.appendChild(shell);
}
