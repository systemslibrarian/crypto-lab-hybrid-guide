import './style.css';
import './extra.css';
import { freshComponents, deriveSessionKey, assess, bytesToHex } from './engine.ts';
import { mountApp } from './ui.ts';

(async function selfTest() {
	console.group('crypto-lab-hybrid-guide: combiner self-test');
	const c = freshComponents();
	const key = await deriveSessionKey(c, 'xwing');
	console.log('Components: X25519 + ML-KEM-768 (simulated 32-byte secrets)');
	console.log('Session key (X-Wing-style):', bytesToHex(key).slice(0, 32) + '\u2026');
	for (const [cb, pb, label] of [
		[false, false, 'both intact'],
		[true, false, 'classical broken'],
		[false, true, 'PQ broken'],
		[true, true, 'both broken'],
	] as [boolean, boolean, string][]) {
		const v = assess({ classicalBroken: cb, pqBroken: pb }, 'xwing');
		console.log(`  ${label}: ${v.remainingBits} bits, secure=${v.secure}`);
	}
	console.groupEnd();
})();

mountApp(document.querySelector<HTMLDivElement>('#app')!);

(function initThemeToggle() {
	const button = document.getElementById('theme-toggle') as HTMLButtonElement | null;
	if (!button) return;
	function apply(theme: string): void {
		document.documentElement.setAttribute('data-theme', theme);
		localStorage.setItem('theme', theme);
		const isDark = theme === 'dark';
		button!.textContent = isDark ? '\u{1F319}' : '\u2600\uFE0F';
		button!.setAttribute('aria-label', isDark ? 'Switch to light mode' : 'Switch to dark mode');
	}
	const current = document.documentElement.getAttribute('data-theme') ?? 'dark';
	apply(current);
	button.addEventListener('click', () => {
		const next = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
		apply(next);
	});
})();
